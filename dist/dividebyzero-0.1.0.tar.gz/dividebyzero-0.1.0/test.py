import dividebyzero as dbz
import numpy as np  # for comparison

# Create a simple matrix
x = dbz.array([
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
])

print("Original array:")
print(x)